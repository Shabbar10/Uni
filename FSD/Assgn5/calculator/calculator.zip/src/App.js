import Calculator from './components/Calculator';
import './output.css'

function App() {
  return (
    <div className="">
      <Calculator />
    </div>
  );
}

export default App;
